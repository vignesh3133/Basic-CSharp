﻿using System;
namespace Q1;
class Program{
    public static void Main(string[] args)
    {
        String name=Console.ReadLine();
        Console.WriteLine("Hello:\n{0}",name);
        Console.WriteLine("Hello:\n"+name);
        Console.WriteLine($"Hello:\n{name}");
        
    }
}
