﻿using System;
namespace Q2;
class Program{
    public static void Main(string[] args)
    {
        int num1=25;
        int num2=4;
        Console.WriteLine("Addition = "+(num1+num2));
        Console.WriteLine("Subtraction = "+(num1-num2));
        Console.WriteLine("Multiplication = "+(num1*num2));
        Console.WriteLine("Division = "+(num1/num2));
        Console.WriteLine("Modulo = "+(num1%num2));
        
    }
} 
