﻿using System;
namespace Q1;
class Program{
    public static void Main(string[] args)
    {
        Console.WriteLine("enter a string");
        string sentence=Console.ReadLine();
        Console.WriteLine("The string you entered is:");
        Console.WriteLine(sentence);
    }
}
